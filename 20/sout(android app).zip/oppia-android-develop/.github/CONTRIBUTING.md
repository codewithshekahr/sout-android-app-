Please see [this link](https://github.com/oppia/oppia-android/wiki) for instructions on how to contribute code to the Oppia Android project. Thanks!
