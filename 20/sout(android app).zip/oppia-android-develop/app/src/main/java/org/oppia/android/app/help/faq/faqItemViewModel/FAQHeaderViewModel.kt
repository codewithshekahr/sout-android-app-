package org.oppia.android.app.help.faq.faqItemViewModel

/** Header view model for the recycler view in [FAQFragment]. */
class FAQHeaderViewModel : FAQItemViewModel()
