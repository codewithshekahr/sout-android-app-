package org.oppia.android.app.home.topiclist

import androidx.lifecycle.ViewModel
import org.oppia.android.app.home.HomeItemViewModel

/** [ViewModel] all topics text in [HomeFragment]. */
object AllTopicsViewModel : HomeItemViewModel()
