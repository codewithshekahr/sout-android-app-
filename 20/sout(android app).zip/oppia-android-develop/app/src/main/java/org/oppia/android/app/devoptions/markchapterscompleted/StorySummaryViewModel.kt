package org.oppia.android.app.devoptions.markchapterscompleted

/** [MarkChaptersCompletedItemViewModel] for displaying a story. */
class StorySummaryViewModel(val storyTitle: String) : MarkChaptersCompletedItemViewModel()
