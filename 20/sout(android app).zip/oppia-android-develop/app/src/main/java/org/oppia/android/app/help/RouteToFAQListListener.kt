package org.oppia.android.app.help

/** Listener for when a selection should result to [FAQListActivity]. */
interface RouteToFAQListListener {
  fun onRouteToFAQList()
}
