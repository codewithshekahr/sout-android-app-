package org.oppia.android.app.administratorcontrols.administratorcontrolsitemviewmodel

/** [ViewModel] for the recycler view in [AdministratorControlsFragment]. */
class AdministratorControlsGeneralViewModel : AdministratorControlsItemViewModel()
