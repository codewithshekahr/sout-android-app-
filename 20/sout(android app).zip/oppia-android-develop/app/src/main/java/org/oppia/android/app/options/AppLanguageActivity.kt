package org.oppia.android.app.options

import android.content.Context
import android.content.Intent
import android.os.Bundle
import org.oppia.android.app.activity.ActivityComponentImpl
import org.oppia.android.app.activity.InjectableAppCompatActivity
import org.oppia.android.app.model.ScreenName.APP_LANGUAGE_ACTIVITY
import org.oppia.android.util.logging.CurrentAppScreenNameIntentDecorator.decorateWithScreenName
import javax.inject.Inject

/** The activity to change the language of the app. */
class AppLanguageActivity : InjectableAppCompatActivity() {
  @Inject
  lateinit var appLanguageActivityPresenter: AppLanguageActivityPresenter
  private lateinit var prefKey: String
  private lateinit var prefSummaryValue: String

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    (activityComponent as ActivityComponentImpl).inject(this)
    prefKey = checkNotNull(intent.getStringExtra(APP_LANGUAGE_PREFERENCE_TITLE_EXTRA_KEY)) {
      "Expected $APP_LANGUAGE_PREFERENCE_TITLE_EXTRA_KEY to be in intent extras."
    }
    prefSummaryValue = if (savedInstanceState == null) {
      checkNotNull(intent.getStringExtra(APP_LANGUAGE_PREFERENCE_SUMMARY_VALUE_EXTRA_KEY)) {
        "Expected $APP_LANGUAGE_PREFERENCE_SUMMARY_VALUE_EXTRA_KEY to be in intent extras."
      }
    } else {
      savedInstanceState.get(SELECTED_LANGUAGE_EXTRA_KEY) as String
    }
    appLanguageActivityPresenter.handleOnCreate(prefKey, prefSummaryValue)
  }

  companion object {
    internal const val APP_LANGUAGE_PREFERENCE_TITLE_EXTRA_KEY =
      "AppLanguageActivity.app_language_preference_title"
    const val APP_LANGUAGE_PREFERENCE_SUMMARY_VALUE_EXTRA_KEY =
      "AppLanguageActivity.app_language_preference_summary_value"
    internal const val SELECTED_LANGUAGE_EXTRA_KEY = "AppLanguageActivity.selected_language"

    /** Returns a new [Intent] to route to [AppLanguageActivity]. */
    fun createAppLanguageActivityIntent(
      context: Context,
      prefKey: String,
      summaryValue: String?
    ): Intent {
      return Intent(context, AppLanguageActivity::class.java).apply {
        putExtra(APP_LANGUAGE_PREFERENCE_TITLE_EXTRA_KEY, prefKey)
        putExtra(APP_LANGUAGE_PREFERENCE_SUMMARY_VALUE_EXTRA_KEY, summaryValue)
        decorateWithScreenName(APP_LANGUAGE_ACTIVITY)
      }
    }

    fun getAppLanguagePreferenceTitleExtraKey(): String {
      return APP_LANGUAGE_PREFERENCE_TITLE_EXTRA_KEY
    }

    fun getAppLanguagePreferenceSummaryValueExtraKey(): String {
      return APP_LANGUAGE_PREFERENCE_SUMMARY_VALUE_EXTRA_KEY
    }
  }

  override fun onBackPressed() {
    val message = appLanguageActivityPresenter.getLanguageSelected()
    val intent = Intent()
    intent.putExtra(MESSAGE_APP_LANGUAGE_ARGUMENT_KEY, message)
    setResult(REQUEST_CODE_APP_LANGUAGE, intent)
    finish()
  }

  override fun onSaveInstanceState(outState: Bundle) {
    super.onSaveInstanceState(outState)
    outState.putString(
      SELECTED_LANGUAGE_EXTRA_KEY,
      appLanguageActivityPresenter.getLanguageSelected()
    )
  }
}
