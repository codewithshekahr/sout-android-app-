package org.oppia.android.app.hintsandsolution

import androidx.lifecycle.ViewModel

/** [ViewModel] for return to lesson button in [HintsAndSolutionDialogFragment]. */
class ReturnToLessonViewModel : HintsAndSolutionItemViewModel()
